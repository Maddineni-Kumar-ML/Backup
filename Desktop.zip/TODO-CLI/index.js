console.log('index.js is Running!!');

const yargs = require('yargs');
const argv = yargs.argv;
const command = argv._[0];
console.log('Running Command:', command);

if(command === 'addTodo') {
    tasks.addTodo(argv.title);
}