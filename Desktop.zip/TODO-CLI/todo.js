const fs = require('fs');
const fetchTodos = () => {
    try {
        let todoString = fs.readFileSync('tasks-data.json');
        return todoString;
    } catch (err) {
        return [];
    }
}

const addTodo = (title) => {
    const todos = fetchTodos();
    const todo = {title};
    todos.push(todo);
}
