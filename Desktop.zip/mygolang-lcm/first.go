package main
import(
	"fmt"
	"https://github.com/Maddineni-Kumar-ML/XLABS-Training/online_file.go"
)

func main() {
	fmt.Println("Hare Krishna!")
	fmt.Println(online_file.onlive_variable)
}