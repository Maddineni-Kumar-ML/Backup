package main

import (
	"fmt"
)

func main() {
	fmt.Println("Hare Rama!")
	fmt.Println(online_file.online_variable)
}
