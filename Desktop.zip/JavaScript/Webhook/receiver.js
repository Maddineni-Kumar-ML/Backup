const express = require('express');
const app = express();
const path = require('path');

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to parse JSON data from the body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Route to handle webhook and render data
app.post('/webhook', (req, res) => {
    const data = req.body;
    console.log(data, "DATA Received in Receiver_______");
    res.send(data);
});

// Route to display a welcome page
app.get('/', (req, res) => {
    res.send('<h1>Welcome to the Webhook Receiver</h1>');
});

// Start the server
app.listen(8080, () => {
    console.log("Server Started at 'http://localhost:8080'");
});
