
const express = require('express');
const session = require('express-session');
const app = express();
const PORT = 8000;
app.set('view engine', 'ejs');

// Middleware to parse JSON and form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set up express-session middleware
app.use(session({
    secret: 'your-secret-key',   // Replace with your own secret key
    resave: false,               // Don't save session if it hasn't been modified
    saveUninitialized: true,     // Save uninitialized sessions
    cookie: { secure: false }    // Set to true if using HTTPS
}));

app.get('/', (req, res) => {
    res.render('login');
});

app.post('/', async (req, res) => {
    // Send the data to the webhook receiver
        const username = req.body.username;
        const loginTime = Date();
        const status = 'Successful Login';

        const data = {
            username: username,
            loginTime: loginTime,
            status: status
        };

        req.session.webhookData = data;
        res.redirect('/webhook');
});

app.get('/webhook', (req, res) => {
    const data = req.session.webhookData;
    console.log(data, "DATA Received in Receiver_______");
    res.render('received', {data:data});
});

app.listen(8080, () => {
    console.log('Server is Running at "http://localhost:8080"');
});
