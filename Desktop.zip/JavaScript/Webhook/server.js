
const express = require('express');
const app = express();
const axios = require('axios');
const path = require('path');



// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render('login');
});

app.post('/', async (req, res) => {
    // Send the data to the webhook receiver
        const username = req.body.username;
        const loginTime = Date();
        const status = 'Successful Login';

        const data = {
            username: username,
            loginTime: loginTime,
            status: status
        };

        const result = await axios.post('http://localhost:8000/webhook', data, {
            headers: { 'Content-Type': 'application/json' }
        });
        console.log(result.data, "RESULT ________________");
        res.render('received', {data:result.data});
});


app.post('/webhook', (req, res) => {
    const data = req.body;
    console.log(data, "DATA Received in Receiver_______");
    res.send(data);
});



app.listen(8000, () => {
    console.log('Server is Running at "http://localhost:8000"');
});



/*
const express = require('express');
const axios = require('axios');
const app = express();
const PORT = 8000;
app.set('view engine', 'ejs');
const path = require('path');
app.set('views', path.join(__dirname, 'views'))

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Main App Route - Serves the form
app.get('/', (req, res) => {
    res.render('login');
});

// Main App Route - Sends the webhook request to the internal /webhook route
app.post('/', async (req, res) => {
    const username = req.body.username;
    const loginTime = Date();
    const status = 'Successful Login';

    const data = {
        username: username,
        loginTime: loginTime,
        status: status
    };


    // Instead of making a request to an external server, make an internal call to /webhook
    const result = await axios.post('http://localhost:8000/webhook', data, {
        headers: { 'Content-Type': 'application/json' }
    });

    console.log(result.data, "Webhook Receiver's Response");
    res.render('received', {data:result.data.receivedData});
    //res.send('Webhook sent and response received from receiver!');
});

// Webhook Receiver Route - Receives the webhook data
app.post('/webhook', (req, res) => {
    const data = req.body;
    console.log('Webhook received:', data);

    // Process the webhook data (log it, save it, etc.)
    res.json({ message: 'Webhook received successfully', receivedData: data });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
*/