var string = 'MapleLabs';
var substring='Labs';

//Using Built-in Methods
function includes(string, substring){
    result=string.includes(substring, 0)
    if(result){
        console.log('Substring Found')
    }
    else{
        console.log('Substring Not Found')
    }
}
function indexof(string, substring){
    result=string.indexOf(substring, 0)
    if(result!=-1){
        console.log('Substring Found')
    }
    else{
        console.log('Substring Not Found')
    }

}

//Using Regular Expressions
function test(string, substring){
    var pattern=new RegExp(substring);
    result=pattern.test(string);
    if(result){
        console.log('Substring Found')
    }
    else{
        console.log('Substring Not Found')
    }
}
function match(string, substring){
    var pattern=new RegExp(substring);
    result=pattern.match(string);
    if(result){
        console.log('Substring Found')
    }
    else{
        console.log('Substring Not Found')
    }
}

test(string, substring);