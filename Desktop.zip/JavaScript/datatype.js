function number(){
    integer = 10;
    float = 3.14;
    infinity = Infinity;
    notANumber = NaN;
    bigint = BigInt(9999999999999999999999999);
    big = 99999999999999999999n;
    console.log(typeof integer, typeof float, typeof infinity, typeof notANumber, typeof bigint, typeof big);
}

function string(){
    s1='Anil';
    s2="Krishna";
    s3=`\nHello ${s1} ${s2}!`;
    console.log(s1, s2, s3);
}

function boolean(){
    a=10;
    b=20;
    c='10';
    d=[10];
    console.log(a==b);
    console.log(a===b);
    console.log(a==c);
    console.log(a===c);
}

function undefined(){
    console.log(x);
    var x;
    console.log(x);
    x=20;
    console.log(x);   
}

function Null(){
    x=null;
    y=null;
    console.log(x, y);
    console.log(x==y);
    console.log(x===y);
}

function symbol(){
    x=Symbol("Anil");
    y=Symbol("Anil");
    console.log(x, y);
    console.log(x==y);
    console.log(x===y);
}

const obj=function object(){
    student = {name:'Anil', age:21};
    console.log(typeof student, student);
    console.log(student.name, student.age, a);
}
a={name:'Anil', age:21};
for (var i in a){
    console.log(i)
    
}
