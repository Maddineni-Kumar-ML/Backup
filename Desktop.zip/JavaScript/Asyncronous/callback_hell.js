function step1(value, callback) {
    callback(value+10, false);
}

function step2(value, callback) {
    callback(value+10, false);
}

function step3(value, callback) {
    callback(value+10, false);
}

step1(10, (result1, err) => {
    if(!err) {
        step2(result1, (result2, err) => {
            if(!err) {
                step3(result2, (result3, err) => {
                    if(!err){
                        console.log(result3)
                    }
                });
            }
        });
    }
});