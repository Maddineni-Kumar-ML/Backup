function step1(value, callback) {
    let result = callback(value+10, false);
    step2(result, (result, err) => {
        if(!err) {
            return result;
        }
    });
}

function step2(value, callback) {
    let result = callback(value+10, false);
    step3(result, (result, err) => {
        if(!err) {
            return result;
        }
    });
}

function step3(value, callback) {
    let result = callback(value+10, false);
    console.log(result);
}

step1(10, (result, err) => {
    return result;
});