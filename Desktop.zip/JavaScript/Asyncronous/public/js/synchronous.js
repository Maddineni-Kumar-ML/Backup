console.log("Maddineni");
console.log("Anil");
setTimeout(() => {
    calculate();
    
}, 2000);
console.log("Kumar");

function calculate() {
    let sum = 0;
    for (let i=0; i<1000000000; i++) {
        sum+=i;
    }
    console.log('Math Result:', sum);
}