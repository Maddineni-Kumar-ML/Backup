console.log('Maddineni');
setTimeout(() => {
    console.log("Anil");
}, 2000);
console.log("Kumar")