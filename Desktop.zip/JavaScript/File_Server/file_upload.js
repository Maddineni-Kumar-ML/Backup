var http = require('http');
var fs = require('fs');
var formidable = require('formidable');
var url = require('url');

http.createServer((req, res) => {
    if(req.url =='/fileupload'){
        var form = new formidable.IncomingForm();
        form.parse(req, (err, fields, files) => {
            res.write('File Uploaded');
            var oldpath = files.filetoupload[0].filepath;
            var newpath = 'C:/Users/kumar_m/'+ files.filetoupload[0].originalFilename;
            console.log(files, oldpath, newpath);
            fs.rename(oldpath, newpath, (err) => {
                if (err) throw err;
                res.write("File Moved");
            });
            res.end();
        });
    }
    else{
        fs.readFile('./file_upload.html', (err, data) => {
            if (err){
                res.write('Error');
            }
            res.writeHead(200, {'Content-Type':'text/html'});
            res.write(data);
            res.write('Created');
            res.end();
        });
    }
}).listen(8000);

