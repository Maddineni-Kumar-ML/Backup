var mail = require('nodemailer');

var transporter = mail.createTransport({
    service: 'gmail',
    auth: {
        user: 'r180864@rguktrkv.ac.in',
        pass: 'Getin@2001'
    }
});

var mailOptions = {
    from: 'r180864@rguktrkv.ac.in',
    to: 'maddineni712@gmail.com',
    subject: 'Sending Test Mail',
    text: 'This is the text!'
};

transporter.sendMail(mailOptions, (err, info) => {
    if (err) {
        console.log(err);
    }
    else{
        console.log('Email Sent: '+info.response);
    }
});