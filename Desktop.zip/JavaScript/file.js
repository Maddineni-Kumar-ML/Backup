var http = require('http');
var fs = require('fs');
/*http.createServer((req, res) => {
    fs.readFile('file.html', (err, data) => {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.write(`${err}`);
        return res.end();
    });
}).listen(8000);*/

fs.readFile('file.html', 'utf-8', (err, data, yes) => {
    if (err) throw err;
    console.log(data, typeof yes);
});

fs.writeFile('file.htm', 'New Content', (err) => {
    if (err) throw err;
    console.log("Updated");
});

fs.appendFile('file.htm', 'Appended Content', (err) => {
    if (err) throw err;
    console.log("Updated");
});

/*fs.unlink('file.html', (err) => {
    if (err) throw err;
    console.log("File Deleted");
});*/

fs.rename('file.htm', 'newname.html', (err) => {
    if (err) throw err;
    console.log("File Renamed");
});



