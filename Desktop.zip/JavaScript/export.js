exports.myDateTime = function () {
    return Date();
  };
//module.exports={sub} //Higher proprity
