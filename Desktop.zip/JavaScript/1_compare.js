var num1 = 23455; 
var num2 = 2344657;
function checK_as_string(num1, num2){

    //Converting Numbers to Strings
    var num1=num1+''; 
    var num2=String(num2);

    //Getting the length of the strings
    var length1=num1.length;
    var length2=num2.length;

    //Checking whether last element in two strings are equal or not using the length of both strings
    if(num1[length1-1]==num2[length2-1]){
        console.log("Equal");
    }
    else{
        console.log("Not Equal")
    }
}
function check_as_int(num1, num2){
    //Getting the Remainders(will get last digit if we divide with 10)
    var rem1=num1%10;
    var rem2=num2%10;

    //Comparing the remainders(last digits)
    if(rem1==rem2){
        console.log(num1+'and'+num2+'Have same last digit')
    }
    else{
        console.log(num1+'and'+num2+'Have different last digit')
    }
}
check_as_int(num1, num2);
checK_as_string(num1, num2)
