array=[1, 2, 3, ' '];
sub=[108, 18];

console.log(sub);

function add(a, b, c){
    return a+b+c
}

console.log(array+sub);
