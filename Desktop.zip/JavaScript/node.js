var http=require('http');
var url = require('url');
http.createServer((req, res) => {
    res.write('Hello Krishna\n');
    res.write(`${req.method}\n`);
    res.write(`${req.url}\n`);
    res.write(`${req.headers}\n`);
    res.write(`${req.httpVersion}\n`);
    res.write(`${req.socket}\n`);
    res.write(`${req.query}\n`);
    res.end();
}).listen(8000);