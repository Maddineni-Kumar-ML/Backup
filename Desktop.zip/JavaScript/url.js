var url = require('url');
var http = require('http');
var addr='http://localhost:8080/default.htm?year=2017&month=february'
var q=url.parse(addr, false);
console.log(q);
http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    var date=new Date();
    res.write(`${date}`);
    res.end(`<h1>Ended</h1>`);
}).listen(8000);