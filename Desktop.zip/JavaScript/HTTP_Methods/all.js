const express = require('express');
const app = express();
app.set('view engine', 'ejs');


app.all('/', (req, res, next) => {
    console.log('Going to access', next);
    //res.render('welcome', {methodName:'all'});
    next();
});

app.get('/', (req, res) => {
    console.log('Accessing');
    res.render('welcome', {methodName:'all'});
});



app.listen(8000, () => {
    console.log('App is running on "http://localhost:8000"');
});