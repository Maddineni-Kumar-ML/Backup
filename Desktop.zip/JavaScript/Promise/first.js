async function promise() {
    let myPromise = new Promise(function(resolve, reject) {
        // some code that takes time, like loading data
        let success = true; // change this to false to check error
    
        if (success) {
            return resolve("The data has loaded successfully!");
        } else {
            return reject("There was an error loading the data.");
        }
    });
    console.log(myPromise)
    return myPromise;
}
result = promise();
result.then((value) => {
    console.log(value)
})