var arr = [2, 4, 6, 8];
function iterate(){
    arr.forEach(function(value){
        
        console.log(value);
    });
}

function iterate_index(){
    arr.forEach(function(value, index){
        arr[index]=arr[index]*2;
    });
    console.log(arr);
}

function iterate_this(){
    arr.forEach(function(value, index){
        arr[index]=value*this.factor
    }, multiply)
}
iterate();