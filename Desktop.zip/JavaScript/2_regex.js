let string = "MapleLabs is a Software Company based on Bengaluru, founded on 2014. MapleLabs is a Service Based Company";

function test(){
    var pattern = /Software/;
    result=pattern.test(string)
    console.log(result)
}
function exec(){
    var pattern = /[a-z]+s\w/i;
    result=pattern.exec(string)
    console.log(result)
}
function match(){
    var pattern = /Maple/g;
    result=string.match(pattern)
    console.log(result)
}
function matchall(){
    var pattern = /Maple/g;
    result=string.matchAll(pattern)
    for(match of result){
        console.log(match)
}
}
function split(){
    var pattern = /Maple/g;
    result=string.split(pattern)
    console.log(result)
}

//Using RegEx
function replace(){
    var pattern = /Maple/g;
    var new_string = 'X';
    result=string.replace(pattern, new_string)
    console.log(result)
}
//Using Built-in
function replace(){
    var pattern = /Maple/g;
    var result=string.replace(pattern, 'X');
    console.log(result)
}
function replace(){
    var pattern = 'Maple';
    var result=string.replaceAll(pattern, 'X');
    console.log(result)
}
replace();