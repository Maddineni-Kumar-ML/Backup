var student = new Map();

function add(key, givenName, givenClass, givenMarks){
    student.set(key, {name:givenName, class:givenClass, marks:givenMarks});
}

function update(key, givenName, givenClass, givenMarks){
    if(student.has(key)){
        add(key, givenName, givenClass, givenMarks)
    }
    else{
        console.log("Key Not Found");
    }
    
}

function del(key){
    student.delete(key)
    console.log("Key and Value pair got deleted")
}

function iterate(){
    //Using For Each
    student.forEach((value,key)=> {
        console.log(key, value['name']);
    })
}

function iterate(){
    //Using For Of Loop
    for(var [key, value] of student){
        console.log(key, value);
    }

    //Using only Key
    for(var key of student.keys()){
        console.log(key, student.get(key));
    }

    //Using only Value
    for(var value of student.values()){
        console.log(value);
    }

    //Using Entries
    for(var [key, value] of student.entries()){
        console.log(key, value);
    }
}


add(101, 'Anil', 'Class-3', 97);
add(102, 'Krishna', 'Class-3', 97);
add(103, 'Rama', 'Class-3', 97);
//console.log(student);
update(101, 'Anil Krish', 'Class-3', 97);
//console.log(student);
//update(103, 'Anil Krish', 'Class-3', 99);
key=101
//console.log(student.key)
iterate();
