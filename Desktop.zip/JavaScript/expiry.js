function expiry(date, seconds){
    let givenDate= new Date(date);
    global.sec=givenDate.getTime();
    var expiryDate = new Date(sec+seconds*1000);
    global.name='Aniul'
    
    var currentDate=new Date();
    //console.log(expiryDate, currentDate);
    if (currentDate > expiryDate) {
        console.log("The given date has expired.");
    } else {
        console.log("The given date has not expired yet.");
    }

    
}
expiry('2024-09-02T14:27:00', 7200);
console.log(new Date('2024-09-02T10:00:00Z'));
console.log(global.name)
