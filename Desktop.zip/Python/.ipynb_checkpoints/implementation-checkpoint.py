from computer import Computer
class Laptop(Computer):
    def __init__(self):
        self.name = "Samsung"
        self._price = 50000
        
    def debug(self):
        debug = False
        '''Debugging Process of Laptop'''
        debug = True
        
        if(debug):
            print("Debug Completed")
        
    def compile(self):
        '''Compiling Process of Laptop'''
        print("Compilation Completed")
        
    def develop(self):
        print("Developing")

    def get_class(self):
        return type(self).mro()[0]

    def get_classes(self):
        return type(self).mro()[1:-1]

class Desktop(Computer):
    def debug(self):
        '''Debugging Process of Desktop'''
        print("Debug Completed : Faster")
        
    def compile(self):
        compiling = 'YES'
        '''Compiling Process of Desktop'''
        compiling = "DONE"
        if(compiling == 'DONE'):
            print("Compilation Completed : Faster")
            
    def develop(self):
        print("Developing: Faster")

