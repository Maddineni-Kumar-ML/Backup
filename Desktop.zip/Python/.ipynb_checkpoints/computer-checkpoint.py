
class Computer():
    
    def develop():
        print("Developing")
   
    def debug():
        pass
    
    def compile():
        pass

class Developer:
    def build(self, comp):
        '''Developer is Building'''
        comp.debug()
        comp.compile()
        return comp