package com.xlabs.mvc.task.service;

import com.xlabs.mvc.task.model.Task;
import com.xlabs.mvc.task.repo.TaskRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class TaskService {
    private final TaskRepo taskRepo;

    @Autowired
    public TaskService(TaskRepo taskRepo) {
        this.taskRepo = taskRepo;
    }

    public List<Task> findAllTasks() {
        return taskRepo.selectAll();
    }

    public Task findTaskById(Long id) {
        return taskRepo.selectWhereId(id);
    }

    public void saveTask(Task task) {
        if(task.getId()==null) {
            taskRepo.add(task);
            System.out.println("Adding_____________"+task.getId());
        }
        else {
            taskRepo.update(task);
        }
    }

    public void editTask(Task task) {
        taskRepo.update(task);
    }

    public void deleteTask(Long id) {
        taskRepo.deleteWhereId(id);
    }
}
