package com.xlabs.mvc.controller;

import com.xlabs.mvc.task.model.Task;
import com.xlabs.mvc.task.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping
public class Control {
    /*@Autowired
    TaskService taskService;*/

    @GetMapping
    public String home() {
        return "welcome";
    }

   /* @GetMapping("/body")
    @ResponseBody
    public List<Task> getTasks() {
        return taskService.findAllTasks();
    }*/
}
