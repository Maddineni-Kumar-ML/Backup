package com.xlabs.mvc.task.repo;

import com.xlabs.mvc.task.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Repo extends JpaRepository<Task, Long> {


}
