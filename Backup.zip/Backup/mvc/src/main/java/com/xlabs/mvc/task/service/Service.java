package com.xlabs.mvc.task.service;

import com.xlabs.mvc.task.model.Task;
import com.xlabs.mvc.task.repo.Repo;
import org.springframework.beans.factory.annotation.Autowired;



import java.util.List;

@org.springframework.stereotype.Service
public class Service {
    private final Repo repo;

    @Autowired
    public Service(Repo repo) {
        this.repo = repo;
    }

    public List<Task> findAllTasks() {
        return repo.findAll();
    }

    public Task findTaskById(Long id) {
        return repo.getReferenceById(id);
    }

    public void saveTask(Task task) {
        repo.save(task);
        System.out.println("Adding_____________"+task.getId());
    }

    public void deleteTask(Long id) {
        repo.deleteById(id);
    }
}