package com.xlabs.mvc.task.repo;

import com.xlabs.mvc.task.model.Task;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TaskRepo {
    final JdbcTemplate jdbcTemplate;

    public TaskRepo(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void add(Task task){
        System.out.println("Task Added");
        String sql = "INSERT INTO task VALUES(?, ?, ?, ?)";
        jdbcTemplate.update(sql, task.getId(), task.getTitle(), task.getDescription(), task.isCompleted());
    }

    public Task selectWhereId(Long id) {

        String sql = "SELECT * FROM task WHERE id = ?";

        return jdbcTemplate.queryForObject(sql, new Object[]{id}, (rs, rowNum) ->
                new Task(
                        rs.getLong("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getBoolean("completed")
                ));
    }

    public void deleteWhereId(Long id) {
        String sql = "DELETE FROM task WHERE id = ?";
        jdbcTemplate.update(sql, id);
        System.out.println("Task Deleted");
    }

    public void update(Task task) {
        String sql = "UPDATE task SET title = ?, description = ?, completed = ? WHERE id = ?";
        jdbcTemplate.update(sql, task.getTitle(), task.getDescription(), task.isCompleted(), task.getId());
        System.out.println("Task Updated");
    }

    public List<Task> selectAll() {
        String sql = "SELECT * FROM task";
        return jdbcTemplate.query(sql, (rs, rowNum) -> new Task(
                rs.getLong("id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getBoolean("completed")
        ));
    }

}