package com.xlabs.mvc.weather.model;

public class Weather {
    private String city;
    private String weather;
    private float temp;
    private String icon;

    public Weather() {
    }


    public Weather(String city, String weather, float temp, String icon) {
        this.city = city;
        this.weather = weather;
        this.temp = temp;
        this.icon = icon;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public float getTemp() {
        return temp;
    }

    public void setTemp(float temp) {
        this.temp = temp;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Override
    public String toString() {
        return "Weather{" +
                "city='" + city + '\'' +
                ", weather='" + weather + '\'' +
                ", temp=" + temp +
                ", icon='" + icon + '\'' +
                '}';
    }
}
