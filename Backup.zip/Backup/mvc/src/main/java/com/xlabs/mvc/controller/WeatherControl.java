package com.xlabs.mvc.controller;

import com.xlabs.mvc.weather.model.Weather;
import com.xlabs.mvc.weather.service.WeatherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/weather")
public class WeatherControl {
    private final WeatherService weatherService;

    public WeatherControl(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @GetMapping
    public String welcome(Model model) {
        System.out.println("Hello Krishna");
        //model.addAttribute("weather", new Weather());
        System.out.println(new Weather().getCity());
        return "weather-form";
    }

    @PostMapping
    public String findWeather(@RequestParam String city, RedirectAttributes redirectAttributes) {
        System.out.println(city);
        Weather weather = weatherService.fetch(city);
        redirectAttributes.addFlashAttribute("weather", weather);
        System.out.println(weather.toString());
        return "redirect:/weather";
    }
}
