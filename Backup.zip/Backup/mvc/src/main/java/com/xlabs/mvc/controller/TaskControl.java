package com.xlabs.mvc.controller;


import com.xlabs.mvc.task.model.Task;
import com.xlabs.mvc.task.service.Service;
import com.xlabs.mvc.task.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/tasks")
public class TaskControl {
    private final TaskService taskService;

    @Autowired
    public TaskControl(TaskService service) {
        this.taskService = service;
    }

    @GetMapping
    public String listTasks(Model model) {
        List<Task> tasks = taskService.findAllTasks();
        model.addAttribute("tasks", tasks);
        //System.out.println(tasks.get(1).getTitle());
        System.out.println("Home");
        return "list";
    }

    @GetMapping("/new")
    public String newTaskForm(Model model) {
        model.addAttribute("task", new Task());
        System.out.println(new Task().getId());
        System.out.println("New Task Form");
        return "form";
    }

    @GetMapping("/edit/{id}")
    public String editTaskForm(@PathVariable Long id, Model model) {
        model.addAttribute("task", taskService.findTaskById(id));
        //model.addAttribute("path", ""+id);
        System.out.println("Edit Task Form" + id);
        return "form";
    }

    @GetMapping("/delete/{id}")
    public String deleteTask(@PathVariable Long id, Model model) {
        taskService.deleteTask(id);
        return "redirect:/tasks";
    }

    @PostMapping
    public String saveTask(@ModelAttribute Task task,  Model model) {
        taskService.saveTask(task);
        System.out.println("Saving task: " + task);
        return "redirect:/tasks";
    }
}
