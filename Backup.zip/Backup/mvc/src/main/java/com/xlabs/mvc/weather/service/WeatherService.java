package com.xlabs.mvc.weather.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.xlabs.mvc.weather.model.Weather;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WeatherService {
    private static final String API_KEY = "8a9faaaa1a4bd018939bc9f6b467cf96";
    private static final String API_URL = "https://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}&units=metric";
    private final RestTemplate restTemplate = new RestTemplate();


    public Weather fetch(String city) {
        // Prepare the URL with the city and API key
        String url = API_URL.replace("{city}", city).replace("{apiKey}", API_KEY);

        try {
            // Make an HTTP GET request and fetch the response
            String response = restTemplate.getForObject(url, String.class);

            // Log the raw response and its class type
            System.out.println(response);
            System.out.println(response.getClass());

            // If the response is not null, parse the JSON response
            if (response != null) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode rootNode = mapper.readTree(response);

                // Extract the necessary data from the JSON response
                String cityName = rootNode.path("name").asText();
                String weatherDescription = rootNode.path("weather").get(0).path("description").asText();
                float temperature = (float) rootNode.path("main").path("temp").asDouble();

                String icon = rootNode.path("weather").get(0).path("icon").asText();

                // Create Weather object and set its properties
                return new Weather(cityName, weatherDescription, temperature, icon);
            } else {
                return null; // Or you can throw an exception
            }
        } catch (JsonProcessingException e) {
            // Handle the JSON parsing exception
            e.printStackTrace();
            return null; // Handle this as per your need
        } catch (Exception e) {
            // Handle any other exceptions (like network issues)
            e.printStackTrace();
            return null; // Handle this as per your need
        }
    }


}
